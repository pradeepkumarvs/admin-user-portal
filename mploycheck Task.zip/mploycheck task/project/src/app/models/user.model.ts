export interface User {
  id: string;
  username: string;
  password: string;
  role: 'General User' | 'Admin';
  name: string;
}

export interface UserCredentials {
  username: string;
  password: string;
}