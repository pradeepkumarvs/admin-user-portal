import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { 
  faUserPlus, 
  faSignOutAlt, 
  faUser, 
  faUserShield, 
  faEnvelope, 
  faKey,
  faUsers,
  faUserCog
} from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, FontAwesomeModule],
  template: `
    <div class="dashboard-container">
      <header>
        <h1>
          <fa-icon [icon]="currentUser?.role === 'Admin' ? faUserShield : faUser" class="mr-2"></fa-icon>
          Welcome, {{ currentUser?.name }}
        </h1>
        <button (click)="logout()" class="logout-btn">
          <fa-icon [icon]="faSignOutAlt"></fa-icon> Logout
        </button>
      </header>

      <div class="user-info">
        <h2>
          <fa-icon [icon]="faUserCog"></fa-icon>
          User Information
        </h2>
        <div class="info-grid">
          <div class="info-item">
            <fa-icon [icon]="faUser"></fa-icon>
            <span>Name:</span> {{ currentUser?.name }}
          </div>
          <div class="info-item">
            <fa-icon [icon]="faUserShield"></fa-icon>
            <span>Role:</span> {{ currentUser?.role }}
          </div>
          <div class="info-item">
            <fa-icon [icon]="faEnvelope"></fa-icon>
            <span>Username:</span> {{ currentUser?.username }}
          </div>
        </div>
      </div>

      <div class="users-list">
        <h2>
          <fa-icon [icon]="faUsers"></fa-icon>
          Users List
        </h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Username</th>
              <th>Role</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let user of users">
              <td>
                <fa-icon [icon]="user.role === 'Admin' ? faUserShield : faUser" class="mr-2"></fa-icon>
                {{ user.name }}
              </td>
              <td>{{ user.username }}</td>
              <td>
                <span [class]="user.role === 'Admin' ? 'role-admin' : 'role-user'">
                  {{ user.role }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div *ngIf="isAdmin" class="add-user-form">
        <h2>
          <fa-icon [icon]="faUserPlus"></fa-icon>
          Add New User
        </h2>
        <form (ngSubmit)="addUser()">
          <div class="form-group">
            <fa-icon [icon]="faUser"></fa-icon>
            <input type="text" [(ngModel)]="newUser.name" name="name" placeholder="Name" required>
          </div>
          <div class="form-group">
            <fa-icon [icon]="faEnvelope"></fa-icon>
            <input type="text" [(ngModel)]="newUser.username" name="username" placeholder="Username" required>
          </div>
          <div class="form-group">
            <fa-icon [icon]="faKey"></fa-icon>
            <input type="password" [(ngModel)]="newUser.password" name="password" placeholder="Password" required>
          </div>
          <div class="form-group">
            <fa-icon [icon]="faUserShield"></fa-icon>
            <select [(ngModel)]="newUser.role" name="role" required>
              <option value="General User">General User</option>
              <option value="Admin">Admin</option>
            </select>
          </div>
          <button type="submit">
            <fa-icon [icon]="faUserPlus"></fa-icon> Add User
          </button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      padding: 2rem;
      max-width: 1200px;
      margin: 2rem auto;
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      padding-bottom: 1rem;
      border-bottom: 2px solid #e9ecef;
    }
    .logout-btn {
      padding: 0.5rem 1rem;
      background: #dc3545;
      color: white;
      border: none;
      border-radius: 4px;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      margin-top: 1rem;
    }
    .info-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem;
      background: white;
      border-radius: 4px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .info-item span {
      font-weight: bold;
      margin-right: 0.5rem;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 1rem 0;
      border-radius: 8px;
      overflow: hidden;
    }
    th, td {
      padding: 1rem;
      border: 1px solid #e9ecef;
      text-align: left;
    }
    th {
      background: #f8f9fa;
      font-weight: 600;
    }
    tr:hover {
      background: #f8f9fa;
    }
    .role-admin {
      background: #4c1d95;
      color: white;
      padding: 0.25rem 0.75rem;
      border-radius: 999px;
      font-size: 0.875rem;
    }
    .role-user {
      background: #059669;
      color: white;
      padding: 0.25rem 0.75rem;
      border-radius: 999px;
      font-size: 0.875rem;
    }
    .add-user-form {
      margin-top: 2rem;
      padding: 2rem;
      background: #f8f9fa;
      border-radius: 8px;
      box-shadow: 0 2px 15px rgba(0,0,0,0.05);
    }
    .form-group {
      margin-bottom: 1rem;
      position: relative;
    }
    .form-group fa-icon {
      position: absolute;
      left: 1rem;
      top: 50%;
      transform: translateY(-50%);
      color: #6b7280;
    }
    input, select {
      width: 100%;
      padding: 0.75rem 1rem 0.75rem 2.5rem;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      font-size: 1rem;
      transition: all 0.3s ease;
    }
    input:focus, select:focus {
      outline: none;
      border-color: #4f46e5;
      box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }
    button {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: #4f46e5;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 1rem;
      font-weight: 500;
    }
    .mr-2 {
      margin-right: 0.5rem;
    }
  `]
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;
  users: User[] = [];
  isAdmin = false;
  faUserPlus = faUserPlus;
  faSignOutAlt = faSignOutAlt;
  faUser = faUser;
  faUserShield = faUserShield;
  faEnvelope = faEnvelope;
  faKey = faKey;
  faUsers = faUsers;
  faUserCog = faUserCog;

  newUser: Partial<User> = {
    name: '',
    username: '',
    password: '',
    role: 'General User'
  };

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.currentUser = this.authService.getCurrentUser();
    this.isAdmin = this.currentUser?.role === 'Admin';
    
    this.loadUsers();
  }

  loadUsers() {
    this.authService.getUsers().subscribe(users => {
      if (this.isAdmin) {
        this.users = users;
      } else {
        this.users = users.filter(user => user.role === 'General User');
      }
    });
  }

  addUser() {
    if (this.isAdmin && this.newUser.name && this.newUser.username && this.newUser.password && this.newUser.role) {
      const user: User = {
        id: Date.now().toString(),
        name: this.newUser.name,
        username: this.newUser.username,
        password: this.newUser.password,
        role: this.newUser.role as 'General User' | 'Admin'
      };

      this.authService.addUser(user).subscribe(() => {
        this.loadUsers();
        this.newUser = {
          name: '',
          username: '',
          password: '',
          role: 'General User'
        };
      });
    }
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}