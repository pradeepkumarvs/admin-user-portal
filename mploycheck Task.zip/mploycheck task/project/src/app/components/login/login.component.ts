import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faUser, faLock } from '@fortawesome/free-solid-svg-icons';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, FontAwesomeModule],
  template: `
    <div class="login-container">
      <div class="login-box">
        <h2>Login</h2>
        <form (ngSubmit)="onSubmit()">
          <div class="form-group">
            <fa-icon [icon]="faUser"></fa-icon>
            <input type="text" [(ngModel)]="username" name="username" placeholder="Username" required>
          </div>
          <div class="form-group">
            <fa-icon [icon]="faLock"></fa-icon>
            <input type="password" [(ngModel)]="password" name="password" placeholder="Password" required>
          </div>
          <button type="submit" [disabled]="loading">
            {{ loading ? 'Loading...' : 'Login' }}
          </button>
        </form>
        <div *ngIf="error" class="error">
          {{ error }}
        </div>
        <div class="demo-credentials">
          <p>Demo Credentials:</p>
          <p>Admin - username: admin, password: admin123</p>
          <p>User - username: user, password: user123</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-container {
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #f5f5f5;
    }
    .login-box {
      padding: 2rem;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
    }
    .form-group {
      margin-bottom: 1rem;
      position: relative;
    }
    .form-group fa-icon {
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      color: #666;
    }
    input {
      width: 100%;
      padding: 0.5rem 0.5rem 0.5rem 2rem;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    button {
      width: 100%;
      padding: 0.5rem;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    button:disabled {
      background: #ccc;
    }
    .error {
      color: red;
      margin-top: 1rem;
    }
    .demo-credentials {
      margin-top: 1rem;
      padding: 1rem;
      background: #f8f9fa;
      border-radius: 4px;
      font-size: 0.9rem;
    }
  `]
})
export class LoginComponent {
  username = '';
  password = '';
  loading = false;
  error = '';
  faUser = faUser;
  faLock = faLock;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit() {
    this.loading = true;
    this.error = '';

    this.authService.login({ username: this.username, password: this.password })
      .subscribe({
        next: (user) => {
          if (user) {
            this.router.navigate(['/dashboard']);
          } else {
            this.error = 'Invalid credentials';
          }
          this.loading = false;
        },
        error: () => {
          this.error = 'An error occurred';
          this.loading = false;
        }
      });
  }
}