import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { User, UserCredentials } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private users: User[] = [
    {
      id: '1',
      username: 'admin',
      password: 'admin123',
      role: 'Admin',
      name: 'Admin User'
    },
    {
      id: '2',
      username: 'user',
      password: 'user123',
      role: 'General User',
      name: 'General User'
    }
  ];

  private currentUser: User | null = null;

  login(credentials: UserCredentials): Observable<User | null> {
    const user = this.users.find(
      u => u.username === credentials.username && u.password === credentials.password
    );
    
    if (user) {
      this.currentUser = user;
      return of(user).pipe(delay(1000)); // Simulate API delay
    }
    
    return of(null).pipe(delay(1000));
  }

  getCurrentUser(): User | null {
    return this.currentUser;
  }

  logout(): void {
    this.currentUser = null;
  }

  addUser(user: User): Observable<boolean> {
    this.users.push(user);
    return of(true).pipe(delay(500));
  }

  getUsers(): Observable<User[]> {
    return of(this.users).pipe(delay(1000));
  }
}